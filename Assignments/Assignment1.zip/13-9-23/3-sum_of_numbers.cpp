#include<iostream>
using namespace std;
int main()
{
    int n,m,sum=0,i;
    
        cout<<"Enter two positive numbers: "<<endl;
        cin>>n>>m;
    
    if(n>0 && m>0)
    {
    	for(i=n;i<=m;i++)
    	{
    		sum=sum+i;
    	}
    	
    	cout<<"The sum is :"<<sum<<endl;
    }
    
    else
    {
    	cout<<"Enter positive numbers only";
    }
    
    return 0;
}
