#include<iostream>
int main()
{
    int n;
    std::cout<<"Enter Number: ";
    std::cin>>n;

    while(n>=10)
    {
        n=n/10;
    }
    std::cout<<n;
}

//--------------------------------------------------------
/*
while(n>=10)
{
    n=n%10;

}
cout<<n;
*/

