#include<iostream>
int main()
{
    int n,rem,sum=0;

    std::cout<<"Enter Number: ";
    std::cin>>n;

    while(n!=0)
    {
        rem=n%10;
        sum=sum+rem;
        n=n/10;
    }
    std::cout<<sum;
}