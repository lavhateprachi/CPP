#include<iostream>
int main()
{
    int num,digit,rem,ctr=0;
    std::cout<<"Enter Number: ";
    std::cin>>num;
    std::cout<<"Enter Digit: ";
    std::cin>>digit;

    while(num!=0)
    {
        rem=num%10;
        if(rem==digit)
        {
             ctr++;
        }
        num = num/10;
    }
    std::cout<<ctr;
}