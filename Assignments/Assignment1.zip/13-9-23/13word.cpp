#include<iostream>
using namespace std;
int main()
{
    int n,digit,rev=0;
    int flag=0;

    do{
        cout<<"Enter Number: ";
        cin>>n;

    } while(n<=0);
    if(n%10==0) 
        flag=1;

    for(;n>0;n=n/10)
    {
        digit=n%10;
        rev=rev*10+digit;
        
    }
    for(;rev!=0;rev/=10)
    {
        digit=rev%10;
        switch(digit)
        {
            case 0: 
                cout<<" Zero";
                break;
            case 1: 
                cout<<" One";
                break;
            case 2: 
                cout<<" Two";
                break;
            case 3:
                cout<<" Three";
                break;
            case 4:
                cout<<" Four";
                break;
            case 5:
                cout<<" Five";
                break;
            case 6:
                cout<<" Six";
                break;
            case 7:
                cout<<" Seven";
                break;
            case 8:
                cout<<" Eight";
                break;
            case 9:
                cout<<" Nine";
                break;
            default:
                cout<<"Invalid..";
                break;
        }
        
    }
    if(flag) 
        cout<<"\tzero";
    return 0;
}
