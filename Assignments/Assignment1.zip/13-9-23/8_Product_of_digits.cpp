#include<iostream>

using namespace std;

int main()
{
	int n,product=1,remainder;
	cout << "Enter a number: "<<endl;
	cin >> n;
	
	if(n==0)
	{
		product=0;
	}
	else
	{
		while (n!=0)
		{
		    	remainder=n%10;
		    	product=product*remainder;
			n = n/10;
		}
	}
	cout<<"The product is: "<<product;
	return 0;
}                             
