#include<iostream>

using namespace std;

int main()
{
    int num;
    do
    {
        cout<<"Enter a positive number: ";
        cin>>num;

    } while(num<=0);

for(int i=1;i<=num;i++)
	{
		if(num%i==0)
		cout<<i<<" ";
		i++;
	}

    return 0;
    
}
