#include <iostream>

using namespace std;

int main()
{
	int n,m,i,r,count=0; int add=0;
	
	do{
		cout<<"Enter a positive number: ";
		cin>>n;
	} while(n<=0);
	m=n;
	while(m!=0)					//Count the number of digits of the number
	{
		m=m/10;
		++count;
		
	}
	
	m=n;
	while(m!=0)					//153 = 1^3 + 5^3 + 3^3
	{
	    r=m%10;
	    int sum=1;
	    for(i=1;i<=count;i++)
	    {
		sum=r*sum;   
	    }
	    add=add+sum;
	    m=m/10;
	}	
	
	if(add==n)
	{
		cout<<"It is Armstrong number\n";
	}
	else
	{
		cout<<"It is not an Armstrong number\n";
	}
	
	return 0;
}
