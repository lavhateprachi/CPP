#include<iostream>
using namespace std;
int main()
{
    int n,digit,i;
    do
    {
        cout<<"Enter Number: ";
        cin>>n;
    } 
    while (n<0);


for(int i=n;i!=0;n=n/10)
{
    if(n<10)
    {
        cout<<"\nFirst Digit:-"<<n;
        break;
    }
}

   return 0;
}
