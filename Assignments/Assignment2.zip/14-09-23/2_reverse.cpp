#include<iostream>
using namespace std;
int main()
{
    int n,i=1,digit,rev=0;

    do{
        cout<<"Enter Number: ";
        cin>>n;

    } while(n<=0);

  for(;n!=0;n%10)
  {
  	
        digit=n%10;
        
        rev=rev*10+digit;
        n=n/10;
  }
 
    cout<<"\n Reverse Number: "<<rev;
    return 0;
}

