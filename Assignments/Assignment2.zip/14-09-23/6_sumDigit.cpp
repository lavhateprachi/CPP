#include<iostream>
using namespace std;
int main()
{
    int n,sum=0,i;

 cout<<"Enter Number: ";
        cin>>n;

  for(;n!=0;n=n/10){
  	i=n%10;
        sum+=i;
  }

    cout<<"\nSum: "<<sum;
    return 0;
}
