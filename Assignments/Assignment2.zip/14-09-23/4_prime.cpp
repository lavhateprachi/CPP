#include<iostream>
using namespace std;
int main()
{
    int n,m,sum=0,i,j,k,prime=1;
    
        cout<<"Enter Range: ";
        cin>>n>>m;
   

 cout<<"\nPrime Numbers: "<<" ";
 
 if(n<m)
 {
    for(i=n;i<=m;i++)
    {
 	
 	 k=2;
     prime=1;
        for(;k<=i/2;k++)
        {
            if(i%k==0)
            {
                prime=0;
                break;
            }
        }

        if(prime==1) cout<<i<<" ";
    }
 }
 

return 0;
}
