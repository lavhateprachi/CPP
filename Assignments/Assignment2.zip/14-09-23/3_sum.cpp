#include<iostream>
using namespace std;
int main()
{
    int n,m,sum=0,i,j;
    cout<<"Enter Two Numbers: ";
    cin>>n>>m;


    if(n<m)
    { 
    
        for(i=n;i<=m;i++)
        {
            sum=sum+i;
            
        }
        
    }
    cout<<"\nSum: "<<sum;
    return 0;
}

