#include<iostream>

void findMax(int a[],int n);
using namespace std;
int main()
{
	int n;
	cout<<"Enter Size: ";
	cin>>n;
	int num[n];
        findMax(num,n);
        
        //return 0;
}
void findMax(int a[],int n)
{
	int i,max,Smax;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
        }
        max=Smax=a[0];
        for(i=1;i<n;i++)
        {
        	if(a[i]>max){
        		Smax=max;
        		max=a[i];
        	}
        	else if(a[i] > Smax)
        	{
        		Smax=max;
        	}
        }
        std::cout<<"Max number: "<<max;
        if(max == a[0]){
        	Smax=a[1];
                for(i=2;i<n;i++)
                {
                	if(a[i]>Smax)
                		Smax=a[i];
                }
        }
	std::cout<<"Second Max: "<<Smax;                	
        
}
