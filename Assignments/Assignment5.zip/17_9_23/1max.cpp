#include<iostream>

int findMax(int num[],int n);
using namespace std;
int main()
{
	int n;
	cout<<"Enter Size: ";
	cin>>n;
	int num[n];
        int max=findMax(num,n);
        cout<<max;
        return 0;
}
int findMax(int num[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		cin>>num[i];
        }
        int max=num[0];
        for(i=1;i<n;i++)
        {
        	if(max < num[i])
        		max = num[i];
        }
        return max;
        
}
