#include<iostream>

void findMin(int a[],int n);
using namespace std;
int main()
{
	int n;
	cout<<"Enter Size: ";
	cin>>n;
	int num[n];
        findMin(num,n);
        
        //return 0;
}
void findMin(int a[],int n)
{
	int i,min,Smin;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
        }
        min=Smin=a[0];
        for(i=1;i<n;i++)
        {
        	if(a[i]<min){
        		Smin=min;
        		min=a[i];
        	}
        	else if(a[i] < Smin)
        	{
        		Smin=min;
        	}
        }
        std::cout<<"Min number: "<<min<<endl;
        if(min == a[0]){
        	Smin=a[1];
                for(i=2;i<n;i++)
                {
                	if(a[i]<Smin)
                		Smin=a[i];
                }
        }
	std::cout<<"Second Min: "<<Smin;                	
        
}
