#include<iostream>

int findMin(int num[],int n);
using namespace std;
int main()
{
	int n;
	cout<<"Enter Size: ";
	cin>>n;
	int num[n];
        int min=findMin(num,n);
        cout<<min
        ;
        return 0;
}
int findMin(int num[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		cin>>num[i];
        }
        int min=num[0];
        for(i=1;i<n;i++)
        {
        	if(min > num[i])
        		min = num[i];
        }
        return min;
        
}
