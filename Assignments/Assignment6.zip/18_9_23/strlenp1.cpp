#include<iostream>
using namespace std;
void read(char s[]);
int main()
{
    char s[100];
    cout<<"Enter string:";
    cin.get(s,20);
    
    read(s);
}
void read(char *s)
{
    int i=0;
    while(*s!= '\0')
    {

        cout<<*s;
        i++;
        s++;
    }
    cout<<endl;
    cout<<"Length:"<<i;
}