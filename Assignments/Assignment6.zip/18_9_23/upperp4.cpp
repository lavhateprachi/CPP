#include<iostream>
using namespace std;
void ToUpper(char s[]);
int main()
{
    char s[100];
    cout<<"Enter String:";
    cin>>s;

    ToUpper(s);
    cout<<"UpperCase: "<<s;
}
void ToUpper(char *s)
{
    int i=0;
    while(*s!='\0')
    {
        if((*s>='a') && (*s<='z'))
        {
            *s=*s-32;
            
        }
        s++;
    }

}