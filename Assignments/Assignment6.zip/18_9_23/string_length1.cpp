#include<iostream>
using namespace std;
void read(char s[]);
int main()
{
    char s[100];
    cout<<"Enter string:";
    cin>>s;
    
    read(s);
}
void read(char s[])
{
    int i=0;
    while(s[i]!= '\0')
    {

        cout<<s[i];
        i++;
    }
    cout<<endl;
    cout<<"Length:"<<i;
}