#include<iostream>
using namespace std;
bool strcmp(char *s,char *d);
int main()
{
    char s[100],d[100];
    cout<<"Enter String1:";
    cin>>s;
    cout<<"Enter String2:";
    cin>>d;

    if(strcmp(s,d))
    {
        cout<<"Strings are EQUAL!";
    }
    else
        cout<<"Strings are NOT EQUAL!";

}
bool strcmp(char *s,char *d)
{
    int i=0,flag=0;
    while((*s!='\0') && (*d!='\0'))
    {
        if(*s==*d)
        {
            flag=0;
            
        }
        else
        {
            flag=1;
            break;
        }
        s++;
        d++;
    }
    if(flag==0)
        return true;
    else
        return false;
}