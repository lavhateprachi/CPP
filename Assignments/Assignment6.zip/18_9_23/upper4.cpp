#include<iostream>
using namespace std;
void ToUpper(char s[]);
int main()
{
    char s[100];
    cout<<"Enter String:";
    cin>>s;

    ToUpper(s);
}
void ToUpper(char s[])
{
    int i=0;
    while(s[i]!='\0')
    {
        if((s[i]>='a') && (s[i]<='z'))
        {
            s[i]=s[i]-32;
            
        }
        i++;
    }
    cout<<"To Upper:"<<s;

}