#include<iostream>
using namespace std;
bool strcmp(char s[],char d[]);
int main()
{
    char s[100],d[100];
    cout<<"Enter String1:";
    cin>>s;
    cout<<"Enter String2:";
    cin>>d;

    if(strcmp(s,d))
    {
        cout<<"Strings are EQUAL!";
    }
    else
        cout<<"Strings are NOT EQUAL!";

}
bool strcmp(char s[],char d[])
{
    int i=0,flag=0;
    while((s[i]!='\0') && (d[i]!='\0'))
    {
        if(s[i]==d[i])
        {
            flag=0;
            
        }
        else
        {
            flag=1;
            break;
        }
        i++;
    }
    if(flag==0)
        return true;
    else
        return false;
}