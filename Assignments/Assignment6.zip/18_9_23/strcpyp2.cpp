#include<iostream>
using namespace std;

void strCopy(char *s,char *d);
int main()
{
    char s[100],d[100];
    cout<<"Enter String:";
    cin.get(s,100);
    strCopy(s,d);
    cout<<"Copied string: "<<d;
    
}
void strCopy(char *s,char *d)
{
    int i=0;
    while(*s!='\0')
    {
        *d=*s;
        s++;
        d++;
    }
    *d='\0';
    
}