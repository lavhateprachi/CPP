#include<iostream>
using namespace std;

void strCopy(char s[],char d[]);
int main()
{
    char s[100],d[100];
    cout<<"Enter String:";
    cin>>s;
    strCopy(s,d);
    
}
void strCopy(char s[],char d[])
{
    int i=0;
    while(s[i]!='\0')
    {
        d[i]=s[i];
        i++;
    }
    d[i]='\0';
    cout<<"Copied String:"<<d<<endl;
    cout<<"Original String:"<<s<<endl;
    cout<<i;
}