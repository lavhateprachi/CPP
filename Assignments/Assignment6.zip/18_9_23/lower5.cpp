#include<iostream>
using namespace std;
void ToLower(char s[]);
int main()
{
    char s[100];
    cout<<"Enter String:";
    cin.get(s,100);

    ToLower(s);
    cout<<"To Lower:"<<s;
}
void ToLower(char s[])
{
    int i=0;
    while(s[i]!='\0')
    {
        if((s[i]>='A') && (s[i]<='Z'))
        {
            s[i]=s[i]+32;
            
        }
        i++;
    }
    //cout<<"To Lower:"<<s;

}