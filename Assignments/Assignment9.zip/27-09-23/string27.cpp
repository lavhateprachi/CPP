#include <iostream>
#include<cstring>
using namespace std;


class String{
	private:
		char *arr;
		int size;
	public :
		String():size(10)
		{	
			arr=new char[size];
			arr="Adarsh";
		}
		String ( char* str)
		{   int length=strlen(str);
			arr=new char[length+1];
			strcpy(arr,str);
		}
		  String(String &obj)
			{ 
			size=obj.size;
			arr=new char[size];
			strcpy(arr,obj.arr);
			}	
			String operator=(String &obj)
			{  

				size=obj.size;
				arr=new char[size];
				strcpy(arr,obj.arr);
				this->display();
				return *this;
			}
			~String()
			{
				cout<<"Deallocate Memmory..";
				delete[] arr;
			}
			void Accept()
			{
				cout<<"Enter String: ";
				cin>>arr;
			}
			
			void display()
			{   
				for(int i=0;arr[i]!='\0';i++)
				{
				
				cout<<arr[i];
				}
				cout<<endl;
			}
};
int main()
{
	 String s1("Prachi");
	 s1.display();

	cout<<"Copy Constructor: ";
	 String s2(s1);
	 s2.display();
	 
	cout<<"Operator Assignment: ";
	String s3;
	String s4;
	s3.Accept();
	s4=s3;
	s4.display();
	 

	
	return 0;
}
