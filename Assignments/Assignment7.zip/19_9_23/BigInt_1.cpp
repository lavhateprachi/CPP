#include <iostream>
using namespace std;
class BigInt {
	int num;
public:
	BigInt() : num(0) {
	}
	BigInt(int n) : num(n) {
	}

	void Read() {
		std::cin >> num;
	}
	void Write() {
		std::cout << num;
	}

	bool operator ==(BigInt obj2) {
		if (num == obj2.num) {
			return true;
		}
		return false;
	}

	void operator >=(BigInt obj2){
		if(num >= obj2.num)
		{
			cout<<"Obj1 is greater than or equal to obj2.."<<endl;
		}
		else
			cout<<"Obj2 is greater than or equal to obj1.."<<endl;
	}
	void operator <(BigInt obj2);
};

void BigInt :: operator <(BigInt obj2)
{
	if(num < obj2.num)
	{
		cout<<"Obj1 is LESS THAN obj2..";
	}
	else
		cout<<"Obj2 is LESS THAN obj1..";
}
int main() {
	
	BigInt b1,b2,b3,b4;
	cout<<"Enter Object Value (b1): ";
	//b1.Read(); 
    b3.Read();
    
	cout<<"Enter Object Value (b2): ";
	//b2.Read(); 

	b4.Read();
    /*
	if (b1 == b2) {
		std::cout << "They are equal\n";
	}
	else {
		std::cout << "They are NOT equal\n";
	}
	*/

	//b1 >= b2;
	
	b3 < b4;

	return 0;
}