#include<iostream>
#include<string.h>
using namespace std;

class String{

    char st[100];
    public:

        String(): st(){
       
        }

        void Read()
        {
            cout<<"Enter String: ";
            cin>>st;
        }
        void show()
        {
            cout<<"Entered String: "<<st;
        }

        bool operator ==(String obj2) {
        
        
            if(strcmp(st,obj2.st)==0)
            {
                return true;
            }
            else
                return false;
        }
        bool operator !=(String obj2) {
        
        
            if(strcmp(st,obj2.st)!=0)
            {
                return true;
            }
            else
                return false;
        }

        void operator <(String obj2) {
        
        
            if(strcmp(st,obj2.st)<0)
            {
                cout<<"Str1 is LESS THAN str2";
            }
            else
                cout<<"Str2 is LESS THAN str1";
        }
        void operator >(String obj2) {
        
        
            if(strcmp(st,obj2.st)>0)
            {
                cout<<"Str1 is GREATER THAN str2";
            }
            else
                cout<<"Str2 is GREATER THAN str1";
        }

        String operator +(String obj2)
        {
            String s3;
            strcpy(s3.st,st);
            strcpy(s3.st," ");
            strcpy(s3.st,obj2.st);

            return s3;
        }

};
int main()
{
    String s1,s2;

    s1.Read();
    s2.Read();
/*
    if(s1 == s2)
    {
        cout<<"Strings are EQUAL...";

    }
    else
        cout<<"Strings are NOT EQUAL...";

    if(s1 != s2)
    {
        cout<<"Strings are NOT EQUAL...";

    }
    else
        cout<<"Strings are EQUAL...";
*/

    s1 < s2;
}