#include<iostream>
using namespace std;

class Date{

    int date,month,year;
    public:
        Date():date(0),month(0),year(0){

        }
        Date(int d,int m,int y):date(d),month(m),year(y){

        }

        void Read()
        {
            cout<<"Enter Date: "<<endl;
            cin>>date;
            cout<<"Enter Month: "<<endl;
            cin>>month;
            cout<<"Enter Year: "<<endl;
            cin>>year;
        }
        void Write()
        {
            cout<<"Date: "<<date<<"-"<<month<<"-"<<year<<endl;
        }

        void operator ==(Date d2){
           if((date == d2.date) && (month == d2.month) && (year == d2.year))
           {
                cout<<"Two object Dates are EQUAL..."<<endl;
           }
           else 
                cout<<"Two object Dates are NOT EQUAL..."<<endl;
            
        }
        void operator !=(Date d2){
            if((year != d2.year) || (month != d2.month) || (date != d2.date))
                cout<<"Dates are NOT EQUAL.."<<endl;
            else
                cout<<"Dates are EQUAL...";
        }

        bool operator <(Date d2);
        bool operator >(Date d2);


};
bool Date:: operator<(Date d2){
    
    if(year < d2.year)
        return true;
    else if((year == d2.year) && (month < d2.month))
        return true;
    else if((year == d2.year) && (month == d2.month) && (date < d2.date))
        return true;
    else
        return false;
}
bool Date:: operator >(Date d2){
    
    if(year > d2.year)
        return true;
    else if((year == d2.year) && (month > d2.month))
        return true;
    else if((year == d2.year) && (month == d2.month) && (date > d2.date))
        return true;
    else
        return false;
}
int main()
{
    Date d1,d2;

    cout<<"Enter Obj1 Date: "<<endl;
    d1.Read();
    cout<<"Enter Obj2 Date: "<<endl;
    d2.Read();

    d1.Write();
    d2.Write();
    
    //d1 == d2;
    //d1 != d2;

/*
    if(d1 < d2)
    {
        cout<<"Date d1 is LESS THAN Date d2..."<<endl;
    }
    else
        cout<<"Date d2 is LESS THAN Date d1..."<<endl;
*/
    if(d1 > d2)
    {
        cout<<"Date d1 is GREATER THAN Date d2..."<<endl;
    }
    else
        cout<<"Date d2 is GREATER THAN Date d1..."<<endl;

    return 0;

}