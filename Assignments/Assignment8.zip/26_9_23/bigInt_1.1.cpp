#include<iostream>
using namespace std;
class BigInt{
    int num;
    public:
    BigInt()
    {
        num=0;
    }
    BigInt(int n)
    {
        num=n;
    }
    void read()
    {
        cout<<"Enter Number: "<<endl;
        cin>>num;
    }
    BigInt& operator+(int no)
    {
        num=num+no;
        return *this;
    }
    BigInt& operator-(int no)
    {
        num=num-no;
        return *this;
    }
    void display()
    {
        cout<<"Number: "<<num<<endl;
    }

};

int main()
{
    BigInt b1(10);
    BigInt b2;
    b2=b1+30;
    cout<<"Addition (+): "<<endl;
    b2.display();


    BigInt b3(5);
    BigInt b4;
    b4=b3-2;
    cout<<"Subtraction (-): "<<endl;
    b4.display();

}
