#include<iostream>
using namespace std;
class BigInt{
    int num;
    public:
    BigInt()
    {
        num=0;
    }
    BigInt(int n)
    {
        num=n;
    }
    void read()
    {
        cout<<"Enter Number: "<<endl;
        cin>>num;
    }
    BigInt operator+(BigInt b2)
    {
        BigInt b1;
        b1.num=num+b2.num;
        return b1;
    }
    BigInt operator-(BigInt b2)
    {
        BigInt b1;
        b1.num=num-b2.num;
        return b1;
    }

    BigInt operator*(BigInt b2)
    {
        BigInt b1;
        b1.num=num*b2.num;
        return b1;
    }

    BigInt operator/(BigInt b2)
    {
        BigInt b1;
        b1.num=num/b2.num;
        return b1;
    }
    BigInt operator++()           //Pre Increament
    {
        ++num;
        return *this;
    }
    BigInt operator++(int)        //Post Increament
    {
        num++;
        return *this;
    }
    BigInt operator--()           //Pre Decreament
    {
        --num;
        return *this;
    }
    BigInt operator--(int)        //Post Decreament
    {
        num--;
        return *this;
    }
    void display()
    {
        cout<<"Number: "<<num<<endl;
    }

};

int main()
{
    BigInt b1;
    //b1.read();
    //b1.display();

    BigInt b2(5);

    BigInt b3;
    //b3=b1+b2;   Addition

    //b3=b1-b2;   Subtraction

    //b3=b1*b2;   Multiplication

    //b3=b1/b2;

    //b3= ++b1;   Pre Increament
    //b3= b2++; 

    b3=--b2;
    b3.display();
}