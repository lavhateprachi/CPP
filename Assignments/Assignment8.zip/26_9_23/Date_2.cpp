#include <iostream>
using namespace std;

class Date
{
    int day;
    int month;
    int year;

public:
    Date(){
        day=0;
        month=0;
        year=0;
    };
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    void Read()
    {
        cout << "Enter Date: ";
        cin >> day;
        cin >> month;
        cin >> year;
    };

    void Write()
    {
        cout<<"Output: "<<endl;
        cout << this->day << " ";
        cout << this->month << " ";
        cout << this->year << " \n ";
    };

    void operator +(int i)
    {
        this->day = this->day + i;
    }
    void operator -(int i)
    {
        this->day = this->day - i;
    }
    void operator -(Date d2)
    {
        this->day = day - d2.day;
        this->month = month - d2.month;
        this->year = year - d2.year;
    }

    bool operator==(Date obj2)
    {
        if (this->day == obj2.day && this->month == obj2.month && this->year == obj2.year)
        {
            cout << "Both Dates are Equal";
            return true;
        }
        else
        {
            cout << "Not Equal \n";
            return false;
        }
    }

    Date operator++(){
        this->day= this->day+1;
        return *this;
    }
    Date operator++(int){
         ++ this->day;
         return *this;
    }
};

int main()
{

Date d3;
cout<<"Object C3: ";
d3.Read();
d3+2;
d3.Write();

Date d1;
cout<<"Object C1: ";
d1.Read();
d1-1;
d1.Write();

cout<<"Object C2: ";
Date d2(17,3,20);
d2++;
d2.Write();


cout<<"Object C4: ";
Date d4(05,03,19);
++d4;
d4.Write();
return 0;
}
